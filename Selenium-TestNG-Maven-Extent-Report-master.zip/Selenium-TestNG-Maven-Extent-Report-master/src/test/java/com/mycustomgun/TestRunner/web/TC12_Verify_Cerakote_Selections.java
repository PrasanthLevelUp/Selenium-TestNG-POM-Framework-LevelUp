package com.mycustomgun.TestRunner.web;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.pages.AccessoriesPage;
import com.mycustomgun.pages.CerakotePage;
import com.mycustomgun.pages.HomePage;
import com.mycustomgun.pages.LowerPage;
import com.mycustomgun.pages.MuzzleDevicePage;
import com.mycustomgun.pages.PlatformPage;
import com.mycustomgun.pages.RailSystemPage;
import com.mycustomgun.pages.SplashKitPage;
import com.mycustomgun.pages.UpperPage;
import com.relevantcodes.extentreports.LogStatus;

public class TC12_Verify_Cerakote_Selections extends TestBase{
	HomePage homepage;
	WebDriver driver;
	PlatformPage platform;
	LowerPage lowerform;
	UpperPage upperform;
	RailSystemPage railsystem;
	MuzzleDevicePage muzzledevices;
	AccessoriesPage accessories;
	SplashKitPage splashkit;
	CerakotePage cerakote;

	@BeforeClass(groups = {"Regression"})
	public void launchApp() {
		driver = startBrowser(prop.getProperty("broswer"), prop.getProperty("base_url"));
		homepage = PageFactory.initElements(driver, HomePage.class);
		platform = PageFactory.initElements(driver, PlatformPage.class);
		getDatas(this.getClass().getSimpleName());
	}

	@Test(priority = 1, description = "This test case will validate GunBuilder Header",groups = {"Regression"})
	public void guestUser_ClickGunBuilder_Pages() throws InterruptedException {
		try {
			test = report.startTest(getData("Description"));
			test.log(LogStatus.INFO, "Test Started" + test.getStartedTime());
			homepage.clickGunbuilder();
			platform.clickPopup();
			platform.plaformpageselection();
			lowerform = PageFactory.initElements(driver, LowerPage.class);
			lowerform.lowerPageSelection();
			upperform = PageFactory.initElements(driver, UpperPage.class);
			upperform.upperPageSelection();
			railsystem = PageFactory.initElements(driver, RailSystemPage.class);
			railsystem.railPageSelection();
			muzzledevices = PageFactory.initElements(driver, MuzzleDevicePage.class);
			muzzledevices.muzzledevicesSelection();
			accessories = PageFactory.initElements(driver, AccessoriesPage.class);
			accessories.accessoriesPageSelection();
			splashkit = PageFactory.initElements(driver, SplashKitPage.class);
			splashkit.splashkitPageSelection();
			cerakote = PageFactory.initElements(driver, CerakotePage.class);
			cerakote.cerakotePageSelection();

		} catch (Exception ex) {
			System.out.println("Msg" + ex.getMessage());
		}
	}

	@AfterClass(groups = {"Regression"})
	public void endApp() {
		driver.close();
	}
}
