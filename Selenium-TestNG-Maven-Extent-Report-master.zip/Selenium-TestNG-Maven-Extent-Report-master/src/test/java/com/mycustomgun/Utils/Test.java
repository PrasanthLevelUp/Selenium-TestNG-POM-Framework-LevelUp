package com.mycustomgun.Utils;

public class Test {

	public static void main(String[] args) {
		String expectedname = "vheuukyrta ||\r\n"
				+ "            MCG CUSTOM GUN";
		String[] name = expectedname.split(" ") ;
		System.out.println(name[0]);
	}

}
