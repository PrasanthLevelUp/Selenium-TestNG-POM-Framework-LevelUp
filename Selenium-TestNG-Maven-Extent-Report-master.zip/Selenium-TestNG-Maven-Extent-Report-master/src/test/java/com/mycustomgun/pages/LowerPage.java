package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class LowerPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils comutils = new CommonUtils();

	public LowerPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-2.tab-pane div.st-dropdown-area"))
	public List<WebElement> lowerattributes;
	@FindBy(css = "	div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.bot_disclamier div.st-builder-gun-price1")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void lowerPageSelection() {
		selectStripped();
		selectPartsKit();
		selectBufferTube();
		selectPistalGrip();
		selectTrigger();
		selectButtstock();
		selectMagazine();
		selectSafety();
		seleutils.javascriptClick(nextbtn, driver, "Click on Next Button");
	}
	
	public void selectStripped() {
		seleutils.javascriptClick(lowerattributes.get(0).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Stripped Lower dropdown");
		List<WebElement> platformlist = lowerattributes.get(0).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Stripped_Lower"))) {
			seleutils.javascriptClick(ele, driver, "Select the Stripped Lower");
			seleutils.priceChecker(getData("Stripped_Lower_Price"),ele,driver);
			//seleutils.speficationValidation(getData("Stripped_Lower"),selecteditemdescription,driver);
			seleutils.speficationValidation("Stripped Lower",getData("Stripped_Lower_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	public void selectPartsKit() {
		seleutils.javascriptClick(lowerattributes.get(1).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Part Kit dropdown");
		List<WebElement> platformlist = lowerattributes.get(1).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Part_Kit"))) {
			seleutils.javascriptClick(ele, driver, "Select the Part Kit");
			seleutils.priceChecker(getData("Part_Kit_Price"),ele,driver);
			seleutils.speficationValidation("Lower Parts Kit",getData("Part_Kit_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	public void selectBufferTube() {
		seleutils.javascriptClick(lowerattributes.get(2).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Buffer Tube dropdown");
		List<WebElement> listsofitems = lowerattributes.get(2).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Buffer_Tube"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Buffer Tube");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Buffer_Tube_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Buffer Tube");
			seleutils.speficationValidation("Buffer Tube",getData("Buffer_Tube_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectPistalGrip() {
		seleutils.javascriptClick(lowerattributes.get(3).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Pistol Grip dropdown");
		List<WebElement> listsofitems = lowerattributes.get(3).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Pistol_Grip"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Pistal Grip");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Pistol_Grip_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Pistal Grip");
			seleutils.speficationValidation("Pistol Grip",getData("Pistol_Grip_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectTrigger() {
		seleutils.javascriptClick(lowerattributes.get(4).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Trigger dropdown");
		List<WebElement> listsofitems = lowerattributes.get(4).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Trigger"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Trigger");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Trigger_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Trigger");
			seleutils.speficationValidation("Trigger",getData("Trigger_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}

	public void selectButtstock() {
		seleutils.javascriptClick(lowerattributes.get(5).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Buttstock dropdown");
		List<WebElement> listsofitems = lowerattributes.get(5).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Buttstock"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Buttstock");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Buttstock_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Buttstock");
			seleutils.speficationValidation("Buttstock",getData("Buttstock_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectMagazine() {
		seleutils.javascriptClick(lowerattributes.get(6).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Magazine dropdown");
		List<WebElement> platformlist = lowerattributes.get(6).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Magazine"))) {
			seleutils.javascriptClick(ele, driver, "Select the Magazine");
			seleutils.priceChecker(getData("Magazine_Price"),ele,driver);
			seleutils.speficationValidation("Magazine",getData("Magazine_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	public void selectSafety() {
		seleutils.javascriptClick(lowerattributes.get(7).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Safety dropdown");
		List<WebElement> platformlist = lowerattributes.get(7).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Safety"))) {
			seleutils.javascriptClick(ele, driver, "Select the Safety");
			seleutils.priceChecker(getData("Safety_Price"),ele,driver);
			seleutils.speficationValidation("Safety",getData("Safety_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	
}
