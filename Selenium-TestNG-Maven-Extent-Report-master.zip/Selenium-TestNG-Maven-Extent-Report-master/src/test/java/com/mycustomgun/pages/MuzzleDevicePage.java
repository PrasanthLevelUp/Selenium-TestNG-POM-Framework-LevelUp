package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;


import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class MuzzleDevicePage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public MuzzleDevicePage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-5.tab-pane div.st-dropdown-area"))
	public List<WebElement> muzzledeviceattributes;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.bot_disclamier div.st-builder-gun-price1")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	
	public void selectMuzzleDevice() {
		seleutils.javascriptClick(muzzledeviceattributes.get(0).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Muzzle Device dropdown");
		List<WebElement> listsofitems = muzzledeviceattributes.get(0).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Muzzle_Device"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Muzzle Device");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Muzzle_Device_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Muzzle Device");
			seleutils.speficationValidation("Muzzle Devices",getData("Muzzle_Device_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
		}


	public void muzzledevicesSelection() {
		
		selectMuzzleDevice();
		seleutils.javascriptClick(nextbtn, driver, "Muzzle Devices Page Next");
	}

}
