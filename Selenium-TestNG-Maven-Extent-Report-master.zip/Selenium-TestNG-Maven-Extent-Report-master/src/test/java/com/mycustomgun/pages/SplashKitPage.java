package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class SplashKitPage extends TestBase {
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public SplashKitPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div.st-dropdown-area div.st-selected-value")) // 5th value
	public List<WebElement> selectedcolur;
	@FindBys(@FindBy(css = "div.st-dropdown-area div.st-dropdown-content div.alignment p"))
	public List<WebElement> selectcolourbtn;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.st-builder-gun-price1")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;

	public void splashkitPageSelection() {

		SplashKitColorSelection();
		seleutils.javascriptClick(nextbtn, driver, "splashkit Page Next");
	}

	public void SplashKitColorSelection() {
		seleutils.javascriptClick(selectedcolur.get(4), driver, "Click on SplashKitColor dropdown");
		for (WebElement ele : selectcolourbtn) {
			if (seleutils.javascriptgetTextbyInnerHtml(ele, driver).contains(getData("SplashKitColor"))) {
				seleutils.javascriptClick(ele, driver, "Select the SplashKitColor");
				seleutils.speficationValidation("Splash Kit", getData("SplashKitColor_Price"), selecteditemname,
						selecteditemprice, driver);
				seleutils.validatepriceColorsplash(gunprice, selecteditemprice, driver);
				break;
			}
		}
	}

}
