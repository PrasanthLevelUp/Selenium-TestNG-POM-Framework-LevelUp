package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class EngravingPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public EngravingPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-7 div.st-dropdown-area div.st-selected-value")) //first 2 
	public List<WebElement> engravattributes; 
	@FindBys(@FindBy(css = "div#step-7 div.st-dropdown-area div.st-radio-area label"))
	public List<WebElement> chooseengravings; 
	@FindBy(css = "div#step-7 input#engraving")
	public WebElement searchtext;
	@FindBys(@FindBy(css = "div#step-7 div.submit-btn button")) //first 2 
	public List<WebElement> butons; 
	@FindBy(css = "div.v-card__actions button")
	public WebElement popupaccept;
	@FindBy(css = "div.v-card__title i")
	public WebElement popupignore;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.st-builder-gun-price")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void engravePageSelection() {
		fillengravText();
		selectEngraving();
		seleutils.javascriptClick(nextbtn, driver, "Click on Engraving Next");
	}
	
	
	public void fillengravText() {
		seleutils.javascriptClick(engravattributes.get(0), driver, "Click on Text Engraving dropdown");
		if(getData("NeedToAddText").equalsIgnoreCase("Yes"))
		{
			//seleutils.javascriptClick(butons.get(1), driver, "Click on Text Engraving Clear");
			//seleutils.JsSendKeys(searchtext,getData("TexttoFill"),"Enter Text Engraving",driver);
			Actions actions = new Actions(driver);
			actions.moveToElement(searchtext).click(searchtext).build().perform();
			seleutils.javascriptClick(searchtext, driver, "Click on Text Engraving");
			seleutils.seleSendKeys(searchtext,getData("TexttoFill"),"Enter Text Engraving",driver);
			seleutils.javascriptClick(searchtext, driver, "Click on Text Engraving Submit");
			seleutils.javascriptClick(butons.get(0), driver, "Click on Text Engraving Submit");
			seleutils.javascriptClick(popupaccept, driver, "Click on Accept Popup");
			seleutils.speficationValidation("Text Engraving",getData("TexttoFill_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validatepriceColor(gunprice,selecteditemprice,driver);
		}
	}
	
	public void selectEngraving() {
	seleutils.javascriptClick(engravattributes.get(1), driver, "Click on Image Engraving dropdown");
		for(WebElement ele: chooseengravings) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Engraving"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Image Engraving");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Engraving_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Image Engraving");
			seleutils.speficationValidation("Image Engraving",getData("Engraving_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice1(gunprice,ele,driver);
			break;
			}
		}
		}

}
