package com.mycustomgun.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;


public class PlatformPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public PlatformPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.okbtn button")
	@CacheLookup
	public WebElement popupOKbtn;
	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "aside div.st-dropdown-area:nth-child(2) div"))
	public List<WebElement> selectplatform;
	@FindBys(@FindBy(css = "aside div.st-dropdown-area:nth-child(3) div"))
	public List<WebElement> selectOrientation;
	@FindBys(@FindBy(css = "aside div.st-dropdown-area:nth-child(4) div"))
	public List<WebElement> selectGunType;
	@FindBys(@FindBy(css = "aside div.st-dropdown-area:nth-child(5) div"))
	public List<WebElement> selectCaliber;
	@FindBy(css = "div.smartwizard-btns button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.bot_disclamier div.st-builder-gun-price1")
	public WebElement gunprice;
	
	
	public void clickPopup() throws InterruptedException {
		seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		seleutils.asserstEqualsvalues(driver.getCurrentUrl(), prop.getProperty("base_url")+"gbuilder1");
	}
	
	public void selectEachHeaderLink() {
		int i=1;	
		for(WebElement ele: headers) {
			seleutils.javascriptClick(ele, driver, "Click to Header " +i++);
		}
	}
	
	public void plaformpageselection() {
		selectPlatform();
		selectOrientation();
		selectGunType();
		selectCaliber();
		try {
			seleutils.TotalpriceChecker(getData("Base_Price"),gunprice,driver);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		seleutils.javascriptClick(nextbtn, driver, "Click on Next Button");
	}
	
	public void selectPlatform() {
		seleutils.javascriptClick(selectplatform.get(1), driver, "Click on  Select platform dropdown");
		List<WebElement> platformlist = selectplatform.get(2).findElements(By.cssSelector("button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("SelectPlatform"))) {
			seleutils.javascriptClick(ele, driver, "Select the platform");
			break;
			}
		}
	}
	
	public void selectOrientation() {
		seleutils.javascriptClick(selectOrientation.get(1), driver, "Click on Orientation dropdown");
		List<WebElement> list = selectOrientation.get(2).findElements(By.cssSelector("button"));
		for(WebElement ele: list) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Orientation"))) {
				seleutils.javascriptClick(ele, driver, "Select the Orientation");
				break;
				}
		}
	}
	
	public void selectGunType() {
		seleutils.javascriptClick(selectGunType.get(1), driver, "Click on GunType dropdown");
		List<WebElement> list = selectGunType.get(2).findElements(By.cssSelector("button"));
		for(WebElement ele: list) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Gun_Type"))) {
				seleutils.javascriptClick(ele, driver, "Select the GunType");
				break;
				}
		}
	}
	public void selectCaliber() {
		seleutils.javascriptClick(selectCaliber.get(1), driver, "Click on Caliber dropdown");
		List<WebElement> list = selectCaliber.get(2).findElements(By.cssSelector("button"));
		for(WebElement ele: list) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Caliber"))) {
				seleutils.javascriptClick(ele, driver, "Select the Caliber");
				break;
				}
		}
	}
}
