package com.mycustomgun.pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class SubmitPage extends TestBase {
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils utils = new CommonUtils();

	public SubmitPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.all p.text")
	public WebElement thankyourtext;
	@FindBy(css = "div.all span.orderid")
	public WebElement orderid;
	

	public void submitverify() {	
		seleutils.asserstEqualsvalues(seleutils.javascriptgetTextbyInnerHtml(thankyourtext, driver).trim(),getData("ThanksMsg"));
		String actualorderid = seleutils.javascriptgetTextbyInnerHtml(orderid, driver);
		try {
			setData("Orderid",actualorderid);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

}
